// swift-tools-version:6.0
import PackageDescription

let package = Package(
    name: "Aera",
    platforms: [.macOS(.v14)],
    products: [
        .executable(name: "Aera", targets: ["AeraApp"]),
    ],
    dependencies: [
        .package(url: "https://github.com/sparkle-project/Sparkle", from: "2.6.0"),
    ],
    targets: [
        .target(
            name: "AeraCore",
            resources: [
                .copy("Resources/ArcFace.mlpkgdata"),
                .copy("Resources/AntiSpoof.mlpkgdata"),
            ]
        ),
        .target(
            name: "AeraEngine",
            dependencies: ["AeraCore"],
            swiftSettings: [.swiftLanguageMode(.v5)]
        ),
        .executableTarget(
            name: "AeraApp",
            dependencies: [
                "AeraCore", "AeraEngine",
                .product(name: "Sparkle", package: "Sparkle"),
            ],
            exclude: ["Animations"],
            resources: [.copy("Brand")],
            swiftSettings: [.swiftLanguageMode(.v5)],
            // Sparkle.framework is embedded in Contents/Frameworks by scripts/build-app.sh.
            linkerSettings: [.unsafeFlags(["-Xlinker", "-rpath", "-Xlinker", "@executable_path/../Frameworks"])]
        ),
        .testTarget(
            name: "AeraCoreTests",
            dependencies: ["AeraCore"],
            resources: [.copy("Fixtures")]
        ),
        .testTarget(
            name: "AeraAppTests",
            dependencies: ["AeraApp", "AeraEngine"],
            swiftSettings: [.swiftLanguageMode(.v5)]
        ),
        .testTarget(
            name: "AeraEngineTests",
            dependencies: ["AeraEngine", "AeraCore"],
            swiftSettings: [.swiftLanguageMode(.v5)]
        ),
    ]
)
