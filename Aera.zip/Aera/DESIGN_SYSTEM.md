# Aera Design System

Aera is a native macOS privacy and authentication companion. Its visual language is **Quiet Intelligence**: calm, precise, minimal, and quietly expressive.

## Brand palette

| Token | Hex | Use |
|---|---|---|
| Primary | `#A855F7` | Primary actions, active controls, key highlights |
| Secondary | `#EC4899` | Secondary accents and selected states |
| Tertiary | `#818CF8` | Supporting accents and information states |
| Neutral | `#14161F` | Dark appearance foundation |

Use the logo's lavender, violet, pink, peach, and warm-orange gradient as an accent rather than a background for every component.

## Appearance

- Light mode: warm white, soft neutral surfaces, graphite text, subtle lavender accents.
- Dark mode: `#14161F` foundation, elevated graphite surfaces, accessible text contrast, restrained violet/pink highlights.
- Typography: native macOS system typography.
- Controls: native SwiftUI/AppKit controls where appropriate.
- Motion: short, purposeful transitions; respect Reduce Motion.

## UX principles

1. Make protection state immediately understandable.
2. Keep common actions easy to reach.
3. Explain permission requirements clearly and without alarmism.
4. Never imply that webcam-based recognition is equivalent to hardware-backed Face ID.
5. Keep all UI status connected to real application state; do not fake successful authentication.
