import AppKit
import SwiftUI
import AeraEngine

@main
struct AeraApp: App {
    @NSApplicationDelegateAdaptor(AppDelegate.self) private var appDelegate
    private let model: AppModel

    init() {
        if CommandLine.arguments.contains("--self-check") {
            let problems = SelfCheck.run()
            for problem in problems { FileHandle.standardError.write(Data("self-check: \(problem)\n".utf8)) }
            print(problems.isEmpty ? "self-check passed" : "self-check failed (\(problems.count) problems)")
            exit(problems.isEmpty ? 0 : 1)
        }
        if let flag = CommandLine.arguments.firstIndex(of: "--render-ui") {
            // QA harness: render the real screens to PNG with sample state, then exit. Runs before
            // the single-instance guard and before anything touches AppModel.shared.
            guard CommandLine.arguments.count > flag + 1 else {
                FileHandle.standardError.write(Data("usage: Aera --render-ui <outputDir>\n".utf8))
                exit(2)
            }
            let dir = CommandLine.arguments[flag + 1]
            MainActor.assumeIsolated { UISnapshot.run(outputDir: dir) }
        }
        // A copy sitting in the Trash (the launch agent can still point at it) must not come back to life.
        if Bundle.main.bundleURL.path.contains("/.Trash/") {
            AppLockAgent.unregister()
            exit(0)
        }
        // The launch agent and the login item can both start us; only one copy may run, and the
        // lowest pid keeps running so two simultaneous starts can never both yield. A duplicate
        // exits NON-zero: launchd only restarts a KeepAlive/SuccessfulExit=false job on failure, so
        // the agent job keeps retrying (every ~10 s) and, if the real instance is later killed,
        // the next retry becomes the running instance and relocks everything.
        let me = ProcessInfo.processInfo.processIdentifier
        if let id = Bundle.main.bundleIdentifier,
           NSRunningApplication.runningApplications(withBundleIdentifier: id).contains(where: { $0.processIdentifier < me }) {
            exit(1)
        }
        model = AppModel.shared
        AppUpdater.shared.start()
    }

    var body: some Scene {
        MenuBarExtra {
            MenuContent(model: model)
        } label: {
            // Use Apple's native vector SF Symbol for a crisp menu-bar glyph at every scale.
            // Unlike a raster PNG, this stays sharp on Retina displays and adapts to the
            // current macOS menu-bar appearance automatically.
            Image(systemName: "faceid")
                .symbolRenderingMode(.monochrome)
                .font(.system(size: 17, weight: .regular))
                .accessibilityLabel("Aera")
        }
        .menuBarExtraStyle(.window)
    }
}
