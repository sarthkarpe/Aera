import SwiftUI

/// Aera design tokens shared by the menu, settings, onboarding, and authentication surfaces.
enum Theme {
    static let accent = Color(light: 0xA855F7, dark: 0xC084FC)
    static let accentInk = Color.white
    static let good = Color(hex: 0x34D399)
    static let warn = Color(hex: 0xF5A524)
    static let bad = Color(hex: 0xF4616D)

    // TEXT variants: use these when the color is a foreground; keep the bright values above for fills and dots.
    static let accentText = Color(light: 0x7E22CE, dark: 0xD8B4FE)
    static let goodText = Color(light: 0x17703B, dark: 0x59C77E)
    static let warnText = Color(light: 0x7A5000, dark: 0xE3A93C)
    static let badText = Color(light: 0xB03024, dark: 0xEF6F5E)

    /// Aera signature gradient: violet, pink, and periwinkle, used sparingly for brand moments.
    static let brandGradient = LinearGradient(
        colors: [Color(hex: 0xA855F7), Color(hex: 0xEC4899), Color(hex: 0x818CF8)],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )

    /// A restrained wash of Aera brand colors for selected rows and subtle emphasis.
    static let softGradient = LinearGradient(
        colors: [Color(hex: 0xA855F7).opacity(0.18), Color(hex: 0xEC4899).opacity(0.13)],
        startPoint: .topLeading, endPoint: .bottomTrailing
    )
}

/// Window backdrop: the base surface with soft violet and apricot glows in opposite corners.
struct AuroraBackground: View {
    var body: some View {
        ZStack {
            Surface.background
            RadialGradient(colors: [Color(hex: 0x8B7CFF).opacity(0.20), .clear],
                           center: .topLeading, startRadius: 0, endRadius: 420)
            RadialGradient(colors: [Color(hex: 0xFF9F6B).opacity(0.16), .clear],
                           center: .bottomTrailing, startRadius: 0, endRadius: 460)
        }
        .ignoresSafeArea()
    }
}

/// 8-pt spacing scale.
enum Spacing {
    static let xxs: CGFloat = 2
    static let xs: CGFloat = 4
    static let sm: CGFloat = 8
    static let md: CGFloat = 12
    static let lg: CGFloat = 16
    static let xl: CGFloat = 24
}

enum Radius {
    static let sm: CGFloat = 8      // icon tile
    static let md: CGFloat = 12     // sidebar item, small tile
    static let lg: CGFloat = 20     // card
    static let style: RoundedCornerStyle = .continuous
}

enum IconSize {
    static let dot: CGFloat = 6
    static let glyph: CGFloat = 12
    static let tile: CGFloat = 22
    static let app: CGFloat = 26
}

/// Mirrors what the views use today (13 semibold rows, 11.5 secondary captions, 15.5 bold titles).
enum Typography {
    static let pageTitle = Font.system(size: 17, weight: .bold, design: .rounded)
    static let sectionTitle = Font.system(size: 12.5, weight: .semibold, design: .rounded)
    static let rowTitle = Font.system(size: 13.5, weight: .semibold, design: .rounded)
    static let body = Font.system(size: 13, weight: .regular, design: .rounded)
    static let caption = Font.system(size: 12.5, weight: .regular, design: .rounded)
    static let mono = Font.system(size: 11, weight: .medium, design: .monospaced)
}

enum Surface {
    static let background = Color(light: 0xFAF9FC, dark: 0x14161F)
    static let sidebar = Color(light: 0xF4F0FA, dark: 0x181A25)
    static let subtle = Color(light: 0xF3EFF9, dark: 0x20232F)
    static let card = Color(light: 0xFFFFFF, dark: 0x1C1F2A)
    static let hairline = Color(light: 0xE7E1EF, dark: 0x303442)
    /// Divider leading inset == row label inset.
    static let rowInset: CGFloat = Spacing.lg
}

extension Color {
    /// Two literals resolved per appearance.
    init(light: UInt32, dark: UInt32) {
        self = Color(nsColor: NSColor(name: nil) { appearance in
            let isDark = appearance.bestMatch(from: [.aqua, .darkAqua]) == .darkAqua
            return NSColor(Color(hex: isDark ? dark : light))
        })
    }

    init(hex: UInt32) {
        self.init(
            red: Double((hex >> 16) & 0xFF) / 255,
            green: Double((hex >> 8) & 0xFF) / 255,
            blue: Double(hex & 0xFF) / 255
        )
    }
}

/// A capsule button: gradient fill for primary, soft fill for secondary. Pressed and disabled states.
/// ponytail: no hover — it needs per-view state (@State is unavailable here); add when the toolchain allows.
struct PillButtonStyle: ButtonStyle {
    enum Kind { case primary, secondary, danger }
    var kind: Kind = .secondary

    func makeBody(configuration: Configuration) -> some View {
        PillBody(configuration: configuration, kind: kind)
    }

    private struct PillBody: View {
        let configuration: ButtonStyleConfiguration
        let kind: Kind
        @Environment(\.isEnabled) private var isEnabled

        var body: some View {
            let pressed = configuration.isPressed && isEnabled
            configuration.label
                .font(.system(size: 12.5, weight: .semibold, design: .rounded))
                .lineLimit(1)
                .minimumScaleFactor(0.85)
                .fixedSize(horizontal: true, vertical: false)
                .padding(.horizontal, 16)
                .padding(.vertical, 7)
                .background(background)
                .foregroundStyle(foreground)
                .frame(minHeight: 36)
                .clipShape(Capsule())
                .overlay(Capsule().stroke(stroke, lineWidth: 1))
                .shadow(color: kind == .primary && isEnabled ? Theme.accent.opacity(0.35) : .clear, radius: 8, x: 0, y: 3)
                .opacity(isEnabled ? (pressed ? 0.85 : 1) : 0.45)
        }

        private var stroke: Color {
            switch kind {
            case .primary: return .clear
            case .secondary: return Surface.hairline
            case .danger: return Theme.bad.opacity(0.35)
            }
        }

        private var background: AnyShapeStyle {
            switch kind {
            case .primary: return AnyShapeStyle(Theme.brandGradient)
            case .secondary: return AnyShapeStyle(Color.primary.opacity(0.06))
            case .danger: return AnyShapeStyle(Color.clear)
            }
        }

        private var foreground: Color {
            switch kind {
            case .primary: return Theme.accentInk
            case .secondary: return .primary
            case .danger: return Theme.badText
            }
        }
    }
}

/// A compact status badge — colored dot plus label.
struct StatusChip: View {
    enum Tone { case good, warn, bad, idle
        var color: Color {
            switch self {
            case .good: return Theme.good
            case .warn: return Theme.warn
            case .bad: return Theme.bad
            case .idle: return .secondary
            }
        }
    }
    let text: String
    let tone: Tone

    var body: some View {
        HStack(spacing: 5) {
            Circle().fill(tone.color).frame(width: 6, height: 6)
            Text(text)
        }
        .font(.system(size: 11, weight: .semibold, design: .rounded))
        .padding(.horizontal, 10)
        .padding(.vertical, 4)
        .background(tone.color.opacity(0.16))
        .clipShape(Capsule())
    }
}
