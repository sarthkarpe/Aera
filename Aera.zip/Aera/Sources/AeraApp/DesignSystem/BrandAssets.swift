import AppKit
import SwiftUI

/// Loads the supplied Aera brand artwork from the app target's bundled Brand resources.
enum AeraBrandAssets {
    /// Always load the actual Aera artwork from the SwiftPM resource bundle. Mark it as a
    /// non-template image so macOS does not replace the brand gradient with a monochrome glyph.
    static func image(named name: String) -> NSImage {
        let candidates: [URL?] = [
            Bundle.module.url(forResource: name, withExtension: "png", subdirectory: "Brand"),
            Bundle.module.resourceURL?.appendingPathComponent("Brand", isDirectory: true)
                .appendingPathComponent("\(name).png")
        ]
        for candidate in candidates.compactMap({ $0 }) {
            if let image = NSImage(contentsOf: candidate) {
                // The menu-bar glyph is a transparent monochrome template so macOS can
                // render it in the correct system color for light and dark menu bars.
                image.isTemplate = (name == "aera-menu")
                return image
            }
        }
        // Make a missing resource visible during development rather than silently showing
        // an unrelated SF Symbol or folder placeholder.
        let fallback = NSImage(size: NSSize(width: 32, height: 32))
        fallback.isTemplate = false
        return fallback
    }
}

struct AeraLogoView: View {
    var size: CGFloat = 32
    var body: some View {
        Image(nsImage: AeraBrandAssets.image(named: "aera-logo"))
            .resizable()
            .interpolation(.high)
            .aspectRatio(contentMode: .fit)
            .frame(width: size, height: size)
            .accessibilityLabel("Aera logo")
    }
}
