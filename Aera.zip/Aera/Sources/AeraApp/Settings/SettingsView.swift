import AppKit
import Observation
import SwiftUI
import AeraEngine

enum SettingsPane: String, CaseIterable, Identifiable {
    case status = "Overview"
    case lockScreen = "Lock Screen"
    case appLock = "App Lock"
    case face = "Your Face"
    case appearance = "Appearance"
    case about = "About Aera"

    var id: String { rawValue }

    var icon: String {
        switch self {
        case .status: return "shield"
        case .lockScreen: return "lock.fill"
        case .appLock: return "square.grid.2x2"
        case .face: return "faceid"
        case .appearance: return "sun.max"
        case .about: return "info.circle"
        }
    }
}

/// Holds the selected sidebar item. A plain `@Observable` class rather than `@State`:
/// the `@State` property-wrapper macro needs a plugin this toolchain (Command Line
/// Tools only, no full Xcode) doesn't have.
@MainActor
@Observable
final class SettingsSelection {
    static let shared = SettingsSelection()
    var pane: SettingsPane = .status
}

/// A real macOS split view — sidebar left, one page right — the same shape as System
/// Settings, Mail, and Notes.
struct SettingsView: View {
    let model: AppModel
    private let selection = SettingsSelection.shared

    /// `initialPaneIndex` (index into the sidebar order) is a snapshot-only hook; the app uses the default.
    init(model: AppModel, initialPaneIndex: Int = 0) {
        self.model = model
        selection.pane = SettingsPane.allCases[initialPaneIndex]
    }

    var body: some View {
        VStack(spacing: 0) {
            brandHeader
            navigationBar
            Rectangle().fill(Surface.hairline).frame(height: 1)
            content
        }
        .frame(minWidth: 760, maxWidth: .infinity, minHeight: 560, maxHeight: .infinity)
        .background(AuroraBackground())
    }

    /// Aera uses a top-level workspace navigation instead of the conventional settings sidebar.
    /// This creates a more product-like security console and gives the brand room to breathe.
    private var brandHeader: some View {
        HStack(spacing: 12) {
            AeraLogoView(size: 42)
            VStack(alignment: .leading, spacing: 2) {
                Text("aera")
                    .font(.system(size: 22, weight: .bold, design: .rounded))
                    .tracking(-0.8)
                    .foregroundStyle(Theme.brandGradient)
                Text("QUIET INTELLIGENCE")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .tracking(1.7)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            HStack(spacing: 7) {
                Circle().fill(model.protectionStatus.tone == .good ? Theme.good : model.protectionStatus.tone == .warn ? Theme.warn : Color.secondary)
                    .frame(width: 7, height: 7)
                Text(model.protectionStatus.title)
                    .font(.system(size: 12, weight: .medium, design: .rounded))
                    .lineLimit(1)
            }
            .padding(.horizontal, 12).padding(.vertical, 8)
            .background(Surface.card.opacity(0.82), in: Capsule())
            .overlay(Capsule().stroke(Surface.hairline, lineWidth: 1))
        }
        .padding(.horizontal, 28)
        .padding(.top, 22)
        .padding(.bottom, 18)
    }

    private var navigationBar: some View {
        HStack(spacing: 7) {
            ForEach(SettingsPane.allCases) { item in
                Button {
                    withAnimation(.easeInOut(duration: 0.18)) { selection.pane = item }
                } label: {
                    HStack(spacing: 8) {
                        Image(systemName: item.icon).font(.system(size: 12, weight: .semibold))
                        Text(item.rawValue).font(.system(size: 12, weight: .semibold, design: .rounded))
                    }
                    .foregroundStyle(selection.pane == item ? Color.white : Color.primary.opacity(0.72))
                    .padding(.horizontal, 13).padding(.vertical, 10)
                    .background {
                        if selection.pane == item {
                            Capsule().fill(Theme.brandGradient)
                                .shadow(color: Color(hex: 0xA855F7).opacity(0.18), radius: 8, y: 3)
                        } else {
                            Capsule().fill(Color.primary.opacity(0.035))
                        }
                    }
                }
                .buttonStyle(.plain)
                .accessibilityLabel(item.rawValue)
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, 28)
        .padding(.bottom, 16)
    }

    private var content: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: Spacing.xl) {
                if let error = model.actionError {
                    Label(error, systemImage: "exclamationmark.triangle.fill")
                        .font(Typography.caption).foregroundStyle(Theme.warnText)
                        .padding(12).frame(maxWidth: .infinity, alignment: .leading)
                        .background(Theme.warn.opacity(0.09), in: RoundedRectangle(cornerRadius: 12))
                }
                switch selection.pane {
                case .status: StatusPane(model: model)
                case .lockScreen: LockScreenPane(model: model)
                case .appLock: AppLockPane(model: model)
                case .face: FacePane(model: model)
                case .appearance: AppearancePane(model: model)
                case .about: AboutPane(model: model)
                }
            }
            .frame(maxWidth: 780, alignment: .leading)
            .padding(.horizontal, 30)
            .padding(.vertical, 26)
            .frame(maxWidth: .infinity, alignment: .top)
        }
    }
}

/// Pane title, one style everywhere.
struct PaneTitle: View {
    let text: String
    var subtitle: String?
    init(_ text: String, subtitle: String? = nil) { self.text = text; self.subtitle = subtitle }
    var body: some View {
        VStack(alignment: .leading, spacing: Spacing.xs) {
            Text(text).font(.system(size: 28, weight: .bold, design: .rounded)).tracking(-0.7)
                .lineLimit(2).accessibilityAddTraits(.isHeader)
            if let subtitle {
                Text(subtitle).font(.system(size: 13, design: .rounded)).foregroundStyle(.secondary)
                    .fixedSize(horizontal: false, vertical: true)
            }
        }
    }
}

/// One section: optional header, the content, optional footnote; identical spacing on every pane.
struct PaneSection<Content: View>: View {
    var header: String? = nil
    var footnote: String? = nil
    @ViewBuilder let content: () -> Content
    var body: some View {
        VStack(alignment: .leading, spacing: Spacing.sm) {
            if let header { SectionHeader(header) }
            content()
            if let footnote { CaptionText(footnote) }
        }
    }
}

/// A switch row inside a card: the title is the VoiceOver label.
private func switchRow(_ title: String, caption: String? = nil, chip: StatusChip? = nil, isOn: Binding<Bool>, disabled: Bool = false) -> some View {
    FormRow(title: title, caption: caption, chip: chip) {
        Toggle(title, isOn: isOn)
            .labelsHidden().toggleStyle(.switch).tint(Theme.accent).disabled(disabled)
    }
}

// MARK: - Overview

private struct StatusPane: View {
    let model: AppModel
    private let selection = SettingsSelection.shared

    private var needsAttention: Bool { model.startupError != nil || !model.problems.isEmpty }
    private var allProtectionOff: Bool { !model.lockScreenEnabled && !model.appLockEnabled }

    var body: some View {
        PaneTitle("Overview", subtitle: "See what’s working and what needs attention.")

        VStack(alignment: .leading, spacing: 0) {
            HStack(alignment: .top, spacing: 18) {
                ZStack {
                    Circle().fill(Color(hex: 0xA855F7).opacity(0.13)).frame(width: 108, height: 108)
                    Circle().stroke(Color(hex: 0xEC4899).opacity(0.38), lineWidth: 1).frame(width: 94, height: 94)
                    AeraLogoView(size: 70)
                }
                .frame(width: 112, height: 112)
                .accessibilityHidden(true)

                VStack(alignment: .leading, spacing: 9) {
                    HStack(spacing: 8) {
                        Text("AERA PROTECTION")
                            .font(.system(size: 10, weight: .bold, design: .rounded)).tracking(1.6)
                            .foregroundStyle(Theme.accentText)
                        StatusChip(text: statusLabel, tone: statusTone)
                    }
                    Text(statusTitle)
                        .font(.system(size: 25, weight: .bold, design: .rounded)).tracking(-0.7)
                        .fixedSize(horizontal: false, vertical: true)
                    Text(statusSubtitle)
                        .font(.system(size: 13, weight: .regular, design: .rounded))
                        .foregroundStyle(.secondary)
                        .fixedSize(horizontal: false, vertical: true)
                    HStack(spacing: 8) {
                        Label(model.lockScreenEnabled ? "Mac protection on" : "Mac protection off", systemImage: "lock.laptopcomputer")
                        Text("·").foregroundStyle(.tertiary)
                        Label("\(model.appLockApps.count) protected apps", systemImage: "square.grid.2x2")
                    }
                    .font(.system(size: 11, weight: .medium, design: .rounded))
                    .foregroundStyle(.secondary)
                    .padding(.top, 2)
                }
                Spacer(minLength: 0)
            }
            .padding(24)

            HStack {
                HStack(spacing: 8) {
                    Circle().fill(statusTone == .good ? Theme.good : statusTone == .warn ? Theme.warn : Color.secondary).frame(width: 7, height: 7)
                    Text(model.paused ? "Recognition paused" : model.setupComplete ? "Aera is ready in the background" : "Finish setup to activate Aera")
                        .font(.system(size: 11, weight: .medium, design: .rounded)).foregroundStyle(.secondary)
                }
                Spacer()
                if let actionTitle {
                    Button(actionTitle) { model.perform(model.protectionStatus.action) }
                        .buttonStyle(PillButtonStyle(kind: .primary))
                }
            }
            .padding(.horizontal, 24).padding(.vertical, 14)
            .background(Color.primary.opacity(0.035))
        }
        .background {
            RoundedRectangle(cornerRadius: 24, style: .continuous)
                .fill(Surface.card.opacity(0.94))
                .overlay(alignment: .topTrailing) {
                    Circle().fill(Color(hex: 0xA855F7).opacity(0.12)).frame(width: 230, height: 230).blur(radius: 38).offset(x: 70, y: -90).clipped()
                }
                .overlay(RoundedRectangle(cornerRadius: 24, style: .continuous).stroke(Surface.hairline, lineWidth: 1))
        }
        .clipShape(RoundedRectangle(cornerRadius: 24, style: .continuous))

        if model.lastEvent != "no checks yet" {
            HStack(alignment: .top, spacing: Spacing.sm) {
                Image(systemName: "clock").foregroundStyle(.secondary)
                VStack(alignment: .leading, spacing: Spacing.xs) {
                    Text("Latest result").font(Typography.rowTitle)
                    CaptionText(model.lastEvent)
                }
            }
            .padding(Spacing.md).frame(maxWidth: .infinity, alignment: .leading)
            .background(Surface.subtle, in: RoundedRectangle(cornerRadius: Radius.md))
        }

        PaneSection(header: "Your protection") {
            SettingsCard {
                manageRow(title: "Lock Screen",
                          caption: lockCaption,
                          status: lockStatusLabel,
                          tone: lockStatusTone,
                          pane: .lockScreen)
                RowDivider()
                manageRow(title: "App Lock",
                          caption: appLockCaption,
                          status: appLockStatusLabel,
                          tone: appLockStatusTone,
                          pane: .appLock)
            }
        }

        PaneSection(header: "General") {
            SettingsCard {
                switchRow("Start at login", caption: "Open Aera when you sign in.",
                          isOn: Binding(get: { model.launchAtLogin }, set: { model.setLaunchAtLogin($0) }))
                RowDivider()
                switchRow("Pause face recognition", caption: "You can still unlock protected apps with Touch ID or your Mac password.",
                          isOn: Binding(get: { model.paused }, set: { model.setPaused($0) }))
            }
        }

        PaneSection(header: "Activity") {
            SettingsCard {
                FormRow(title: "Lock Screen unlocks today", caption: "Successful face unlocks on this Mac.") {
                    Text("\(model.unlocksToday)").font(.system(size: 15, weight: .semibold).monospacedDigit())
                }
                RowDivider()
                FormRow(title: "Recent activity", caption: model.lastEvent == "no checks yet" ? "No unlock activity yet." : model.lastEvent) {
                    Button("Open Log…") { NSWorkspace.shared.open(model.log.url) }
                        .buttonStyle(PillButtonStyle(kind: .secondary))
                }
            }
        }
    }

    private var statusTitle: String { model.protectionStatus.title }
    private var statusSubtitle: String { model.protectionStatus.detail }
    private var statusLabel: String { model.protectionStatus.label }
    private var statusTone: StatusChip.Tone { model.protectionStatus.tone }
    private var statusIcon: String { statusTone == .warn ? "exclamationmark" : model.paused ? "pause.fill" : "shield" }
    private var actionTitle: String? { model.protectionStatus.actionTitle }
    private var lockStatusLabel: String { model.lockStatus.label }
    private var lockStatusTone: StatusChip.Tone { model.lockStatus.tone }
    private var lockCaption: String { model.lockStatus.detail }
    private var appLockStatusLabel: String { model.appStatus.label }
    private var appLockStatusTone: StatusChip.Tone { model.appStatus.tone }
    private var appLockCaption: String { model.appStatus.detail }

    private func manageRow(title: String, caption: String, status: String, tone: StatusChip.Tone, pane: SettingsPane) -> some View {
        FormRow(title: title, caption: caption, chip: StatusChip(text: status, tone: tone)) {
            Button("Manage") { selection.pane = pane }
                .buttonStyle(PillButtonStyle(kind: .secondary))
                .accessibilityLabel("Manage \(title)")
        }
    }
}

// MARK: - Lock Screen

private struct LockScreenPane: View {
    let model: AppModel

    // Keep password input in native SwiftUI state. SecureField is sensitive to stable
    // bindings, so avoid routing keystrokes through a custom Observable reference.
    @State private var password = ""
    @State private var confirm = ""
    @State private var message: String?
    @State private var messageIsError = false
    @State private var isChanging = false
    @State private var saveCount = 0
    @State private var isSaving = false
    @FocusState private var focusedPasswordField: PasswordField?

    private enum PasswordField: Hashable { case password, confirm }

    private var hasPassword: Bool {
        _ = saveCount
        return model.hasSavedPassword
    }

    var body: some View {
        PaneTitle("Lock Screen", subtitle: "Unlock your Mac with face recognition.")

        SettingsCard {
            switchRow("Unlock your Mac with face recognition", chip: lockChip,
                      isOn: Binding(get: { model.lockScreenEnabled }, set: { model.setLockScreenEnabled($0) }))
            if !hasPassword, let reason = model.actionError {
                RowDivider()
                HStack(alignment: .firstTextBaseline, spacing: Spacing.sm) {
                    Image(systemName: "exclamationmark.triangle.fill").foregroundStyle(Theme.warn)
                    Text(reason).foregroundStyle(Theme.warnText).fixedSize(horizontal: false, vertical: true)
                    Spacer(minLength: 0)
                }
                .font(Typography.caption)
                .padding(.horizontal, Surface.rowInset).padding(.vertical, Spacing.md)
            }
        }

        PaneSection(header: "Lock Screen requirements") {
            SettingsCard {
                FormRow(title: "Face setup", caption: model.setupComplete
                        ? "Face recognition is set up on this Mac."
                        : "Set up and test face recognition before enabling Lock Screen unlock.") {
                    HStack(spacing: Spacing.sm) {
                        StatusChip(text: model.setupComplete ? "Ready" : "Not set up", tone: model.setupComplete ? .good : .warn)
                        Button("Your Face") { model.showSettings(.face) }
                            .buttonStyle(PillButtonStyle(kind: .secondary))
                    }
                }
                RowDivider()
                FormRow(title: "Camera access", caption: "Needed for face recognition.") {
                    if model.cameraAuthorized {
                        StatusChip(text: "Allowed", tone: .good)
                    } else {
                        Button("Allow Camera Access…") { model.requestCameraAccess() }
                            .buttonStyle(PillButtonStyle(kind: .secondary))
                    }
                }
                RowDivider()
                FormRow(title: "Accessibility access", caption: "Lets Aera enter your saved Mac login password after recognition.") {
                    if model.accessibilityTrusted {
                        StatusChip(text: "Allowed", tone: .good)
                    } else {
                        Button("Review Access…") { model.openSystemSettings(anchor: "Privacy_Accessibility") }
                            .buttonStyle(PillButtonStyle(kind: .secondary))
                    }
                }
                RowDivider()
                passwordForm
            }
        }

        CaptionText("After recognizing you, Aera enters your saved Mac login password. Your Mac password and Touch ID continue to work as usual.")
        CaptionText("Face recognition uses a regular camera, without iPhone Face ID’s depth sensing.")
        CaptionText("Your saved password is encrypted on this Mac and never sent anywhere.")
    }

    private var passwordForm: some View {
        VStack(alignment: .leading, spacing: Spacing.md) {
            HStack(spacing: Spacing.md) {
                VStack(alignment: .leading, spacing: Spacing.xxs) {
                    Text("Saved password").font(Typography.rowTitle)
                    CaptionText(hasPassword ? "Encrypted on this Mac." : "Required for Lock Screen face unlock.")
                    if hasPassword, !isChanging, let message {
                        Text(message).font(Typography.caption).foregroundStyle(Theme.goodText)
                    }
                }
                Spacer(minLength: Spacing.sm)
                StatusChip(text: hasPassword ? "Saved" : "Not saved", tone: hasPassword ? .good : .warn)
                if hasPassword, !isChanging {
                    Button("Update Saved Password…") { isChanging = true; message = nil }
                        .buttonStyle(PillButtonStyle(kind: .secondary))
                }
            }
            if !hasPassword || isChanging { fields }
        }
        .padding(Spacing.lg)
        .onChange(of: focusedPasswordField) { _, newValue in
            // Aera normally runs as a menu-bar utility. Activate the app when a secure
            // field receives focus so keyboard input is delivered to the settings window.
            if newValue != nil {
                NSApp.activate(ignoringOtherApps: true)
                NSApp.keyWindow?.makeKeyAndOrderFront(nil)
            }
        }
    }

    @ViewBuilder private var fields: some View {
        SecureField(hasPassword ? "New login password" : "Login password", text: $password)
            .textFieldStyle(.roundedBorder)
            .focused($focusedPasswordField, equals: .password)
            .disabled(false)
            .accessibilityLabel(hasPassword ? "New login password" : "Login password")
        SecureField("Confirm password", text: $confirm)
            .textFieldStyle(.roundedBorder)
            .focused($focusedPasswordField, equals: .confirm)
            .disabled(false)
            .accessibilityLabel("Confirm password")
        HStack(spacing: Spacing.md) {
            Button(hasPassword ? "Update Password" : "Save Password") { Task { await save() } }
                .buttonStyle(PillButtonStyle(kind: .primary))
                .disabled(password.isEmpty || confirm.isEmpty || password != confirm || isSaving)
            if hasPassword {
                Button("Cancel") { isChanging = false; password = ""; confirm = ""; message = nil }
                    .buttonStyle(PillButtonStyle(kind: .secondary))
            }
            if let message {
                Text(message).font(Typography.caption)
                    .foregroundStyle(messageIsError ? Theme.badText : Theme.goodText)
                    .fixedSize(horizontal: false, vertical: true)
            }
            Spacer(minLength: 0)
        }
    }

    private func save() async {
        guard !isSaving else { return }
        guard password == confirm else {
            message = "The two passwords don't match."; messageIsError = true
            return
        }
        isSaving = true
        defer { isSaving = false }
        if let error = await model.saveLoginPassword(password) {
            message = error; messageIsError = true
            return
        }
        let wasBlocked = model.actionError != nil
        password = ""; confirm = ""
        message = "Password saved."; messageIsError = false
        isChanging = false
        saveCount += 1
        model.actionError = nil
        if wasBlocked { model.setLockScreenEnabled(true) }
    }

    private var lockChip: StatusChip { StatusChip(text: model.lockStatus.label, tone: model.lockStatus.tone) }
}

// MARK: - Face Data

private struct FacePane: View {
    let model: AppModel

    var body: some View {
        PaneTitle("Your Face", subtitle: "Use the same face setup for Lock Screen and App Lock.")

        statusCard

        PaneSection(header: "Face recognition") {
            SettingsCard {
                FormRow(title: "Test face recognition", caption: "Check your lighting, then see if Aera recognizes you.") {
                    Button("Test Face Recognition…") { model.openTest() }
                        .buttonStyle(PillButtonStyle(kind: .secondary))
                        .disabled(!model.setupComplete)
                }
                RowDivider()
                FormRow(title: "Face setup", caption: model.setupComplete
                        ? "Verify it’s you, capture new face data, then test recognition."
                        : "Capture a few clear samples to set up face recognition.") {
                    Button(model.setupComplete ? "Set Up Again…" : "Set Up Face Recognition…") {
                        model.setupComplete ? model.reEnroll() : model.openSetup()
                    }
                    .buttonStyle(PillButtonStyle(kind: .secondary))
                }
                RowDivider()
                FormRow(title: "Camera access", caption: model.cameraAuthorized
                        ? "Available for face recognition."
                        : "Allow camera access to use face recognition.") {
                    if model.cameraAuthorized {
                        StatusChip(text: "Allowed", tone: .good)
                    } else {
                        Button("Allow Camera Access…") { model.requestCameraAccess() }
                            .buttonStyle(PillButtonStyle(kind: .secondary))
                    }
                }
            }
        }

        PaneSection(header: "Face match requirement", footnote: strictnessFootnote) {
            SettingsCard {
                CaptionText("Applies to Lock Screen and App Lock.").frame(maxWidth: .infinity, alignment: .leading).padding(.horizontal, Spacing.lg).padding(.top, Spacing.md)
                Picker("Face match requirement", selection: Binding(get: { model.strictness }, set: { model.setStrictness($0) })) {
                    ForEach(MatchStrictness.allCases, id: \.self) { level in Text(matchLabel(level)).tag(level) }
                }
                .pickerStyle(.segmented).labelsHidden().padding(Spacing.lg)
            }
        }

        HStack(alignment: .top, spacing: Spacing.sm) {
            Image(systemName: "info.circle").foregroundStyle(.secondary).accessibilityHidden(true)
            CaptionText("Your face data is encrypted and stored on this Mac, not as photos. The encryption key is kept in your Mac’s Keychain.")
        }
        .padding(.horizontal, Spacing.xs)

        if model.setupComplete {
            Button("Remove Face Data…") { confirmRemoval() }
                .buttonStyle(.plain)
                .font(.system(size: 12.5, weight: .medium))
                .foregroundStyle(Theme.badText)
                .accessibilityHint("Removes your face data and turns off Lock Screen face unlock.")
        }
    }

    private func matchLabel(_ level: MatchStrictness) -> String {
        switch level {
        case .relaxed: return "Lower"
        case .normal: return "Standard"
        case .strict: return "Higher"
        }
    }

    private var strictnessFootnote: String {
        switch model.strictness {
        case .relaxed: return "A lower match requirement may make recognition easier, with a greater risk of false matches."
        case .normal: return "The standard match requirement. Recognition depends on lighting and camera conditions."
        case .strict: return "A higher match requirement can reject more attempts, especially in difficult lighting."
        }
    }

    /// Enrolled: a teal confirmation. Not enrolled: a direct setup action.
    @ViewBuilder private var statusCard: some View {
        FaceCard(fill: Surface.card, stroke: Surface.hairline) {
            VStack(spacing: Spacing.md) {
                FaceIconCircle(icon: "faceid", tint: Theme.good, ink: Theme.goodText)
                Text(model.faceStatus.title).font(.system(size: 20, weight: .semibold))
                CaptionText(model.faceStatus.detail).multilineTextAlignment(.center)
                StatusChip(text: model.faceStatus.label, tone: model.faceStatus.tone)
                if let title = model.faceStatus.actionTitle {
                    Button(title) { model.perform(model.faceStatus.action) }.buttonStyle(PillButtonStyle(kind: .secondary))
                }
            }.frame(maxWidth: .infinity).padding(.vertical, Spacing.lg)
        }
    }

    /// Cancel is the default (Return) button; the destructive confirm is second and never the default.
    private func confirmRemoval() {
        let alert = NSAlert()
        alert.messageText = "Remove your face data?"
        alert.informativeText = "This deletes your enrolled face, the stored login password and the encryption key and turns off lock-screen face unlock. You can set Aera up again afterwards."
        alert.alertStyle = .warning
        alert.addButton(withTitle: "Cancel")
        let remove = alert.addButton(withTitle: "Remove")
        remove.hasDestructiveAction = true
        if alert.runModal() == .alertSecondButtonReturn {
            model.removeAllData()
        }
    }
}

// MARK: - Appearance

@MainActor @Observable
private final class AnimationDemo {
    static let shared = AnimationDemo()
    var phase = "idle"
    var task: Task<Void, Never>?
    func replay(_ model: AppModel, reducedMotion: Bool, playNotch: Bool = true) {
        task?.cancel()
        if playNotch { NotchOverlayController.shared.preview(model.animationStyle) }
        phase = reducedMotion ? "success" : "scanning"
        task = Task { @MainActor in
            if !reducedMotion {
                try? await Task.sleep(for: .milliseconds(1100))
                guard !Task.isCancelled else { return }
                phase = "success"
            }
            try? await Task.sleep(for: .milliseconds(1400))
            guard !Task.isCancelled else { return }
            phase = "idle"
        }
    }
}

private struct AppearancePane: View {
    let model: AppModel
    private let demo = AnimationDemo.shared
    @Environment(\.accessibilityReduceMotion) private var reduceMotion
    var body: some View {
        PaneTitle("Appearance", subtitle: "Choose the animation shown during face unlock.")
        SettingsCard {
            switchRow("Show unlock animation", caption: "A brief confirmation at the top of your screen.",
                      isOn: Binding(get: { model.animationEnabled }, set: { model.setAnimationEnabled($0) }))
        }
        PaneSection(header: "Unlock style", footnote: "The app follows your macOS appearance and reduced-motion preferences.") {
            SettingsCard {
                VStack(spacing: 18) {
                    ZStack(alignment: .top) {
                        RoundedRectangle(cornerRadius: 12).fill(Surface.subtle)
                        HStack(spacing: 26) {
                            Image(systemName: "lock.fill").foregroundStyle(.white)
                            Image(systemName: demo.phase == "success" ? "checkmark" : "faceid")
                                .foregroundStyle(demo.phase == "success" ? Theme.good : Theme.accent)
                        }
                        .font(.system(size: model.animationStyle == .minimal ? 18 : 28))
                        .frame(width: model.animationStyle == .minimal ? 160 : 220, height: model.animationStyle == .minimal ? 44 : 80)
                        .background(.black, in: RoundedRectangle(cornerRadius: 22))
                        .padding(.top, 18).opacity(model.animationEnabled ? 1 : 0)
                    }.frame(height: 130).accessibilityHidden(true)
                    CaptionText(!model.animationEnabled ? "Unlock animation is off." : demo.phase == "scanning" ? "Recognizing…" : demo.phase == "success" ? "Recognized." : "Choose a style, then replay.")
                    Picker("Unlock style", selection: Binding(get: { model.animationStyle }, set: {
                        model.setAnimationStyle($0)
                        demo.replay(model, reducedMotion: reduceMotion, playNotch: false)
                    })) {
                        ForEach(UnlockAnimationStyle.allCases) { style in Text(style.title).tag(style) }
                    }.pickerStyle(.segmented).disabled(!model.animationEnabled)
                    Button("Replay animation") { demo.replay(model, reducedMotion: reduceMotion) }
                        .buttonStyle(PillButtonStyle(kind: .secondary)).disabled(!model.animationEnabled)
                }.padding(Spacing.lg)
            }
        }
    }
}

// MARK: - About

private struct AboutPane: View {
    let model: AppModel

    private var version: String {
        (Bundle.main.object(forInfoDictionaryKey: "CFBundleShortVersionString") as? String) ?? "1.0.0"
    }

    var body: some View {
        PaneTitle("Aera", subtitle: "Your face. Your Mac. Your privacy.")

        VStack(spacing: Spacing.md) {
            AeraLogoView(size: 88)
                .accessibilityHidden(true)
            Text("Version \(version)").font(Typography.mono).foregroundStyle(.secondary)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, Spacing.xl)

        if AppUpdater.shared.isAvailable || AppModel.uiSnapshotMode {
            SettingsCard {
                FormRow(title: "Software updates", caption: "Aera asks before installing updates.") {
                    Button("Check for Updates…") { AppUpdater.shared.checkNow() }
                        .buttonStyle(.plain).foregroundStyle(Theme.accent)
                        .disabled(!AppUpdater.shared.canCheck && !AppModel.uiSnapshotMode)
                }
            }
        }
        if AppUpdater.shared.isAvailable || AppModel.uiSnapshotMode {
            SettingsCard {
                switchRow("Check for updates automatically", isOn: Binding(get: { AppUpdater.shared.checksAutomatically }, set: { AppUpdater.shared.setChecksAutomatically($0) }))
            }
        }

        PaneSection(header: "Uninstall") {
            SettingsCard {
                FormRow(title: "Uninstall Aera",
                        caption: "Removes the app, your face data, saved password and settings from this Mac.") {
                    Button("Uninstall…") { confirmUninstall() }
                        .buttonStyle(PillButtonStyle(kind: .danger))
                }
            }
        }
    }

    /// Cancel is the default (Return) button; the destructive confirm is second and never the default.
    private func confirmUninstall() {
        let alert = NSAlert()
        alert.messageText = "Uninstall Aera?"
        alert.informativeText = "This deletes your enrolled face, the stored login password, the encryption key, your settings and the app itself, and turns off lock-screen unlock and App Lock. It can't be undone."
        alert.alertStyle = .warning
        alert.addButton(withTitle: "Cancel")
        let remove = alert.addButton(withTitle: "Uninstall")
        remove.hasDestructiveAction = true
        if alert.runModal() == .alertSecondButtonReturn {
            Task { await model.uninstall() }
        }
    }

}


// MARK: - Face Data pieces

private struct FaceCard<Content: View>: View {
    let fill: Color
    let stroke: Color
    @ViewBuilder let content: () -> Content
    var body: some View {
        content()
            .padding(Spacing.lg)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(fill, in: RoundedRectangle(cornerRadius: Radius.lg, style: Radius.style))
            .overlay(RoundedRectangle(cornerRadius: Radius.lg, style: Radius.style).stroke(stroke, lineWidth: 1))
    }
}

private struct FaceIconCircle: View {
    let icon: String
    let tint: Color
    let ink: Color
    var body: some View {
        Image(systemName: icon)
            .font(.system(size: 18, weight: .semibold))
            .foregroundStyle(ink)
            .frame(width: 44, height: 44)
            .background(tint.opacity(0.18), in: Circle())
            .accessibilityHidden(true)
    }
}

/// A tappable card: icon, title, one-line caption, chevron. `danger` tints it red; `prompt` amber.
private struct FaceActionRow: View {
    enum Tone { case neutral, danger, prompt }
    let icon: String
    let title: String
    let caption: String
    let tone: Tone
    let action: () -> Void

    @Environment(\.isEnabled) private var isEnabled

    private var ink: Color {
        switch tone {
        case .neutral: return Theme.accentText
        case .danger: return Theme.badText
        case .prompt: return Theme.warnText
        }
    }
    private var tint: Color {
        switch tone {
        case .neutral: return Theme.accent
        case .danger: return Theme.bad
        case .prompt: return Theme.warn
        }
    }

    var body: some View {
        Button(action: action) {
            FaceCard(fill: tone == .neutral ? Surface.card : tint.opacity(0.10),
                     stroke: tone == .neutral ? Surface.hairline : tint.opacity(0.35)) {
                HStack(spacing: Spacing.lg) {
                    FaceIconCircle(icon: icon, tint: tint, ink: ink)
                    VStack(alignment: .leading, spacing: Spacing.xxs) {
                        Text(title).font(Typography.sectionTitle)
                            .foregroundStyle(tone == .danger ? Theme.badText : Color.primary)
                        CaptionText(caption)
                    }
                    Spacer(minLength: Spacing.sm)
                    Image(systemName: "chevron.right").font(.system(size: 12, weight: .semibold))
                        .foregroundStyle(.secondary).accessibilityHidden(true)
                }
            }
            .contentShape(Rectangle())
        }
        .buttonStyle(PressableCardStyle())
        .opacity(isEnabled ? 1 : 0.5)
        .accessibilityLabel(title)
        .accessibilityHint(caption)
    }
}

/// Dims slightly while pressed; the card itself supplies all the visuals.
private struct PressableCardStyle: ButtonStyle {
    func makeBody(configuration: Configuration) -> some View {
        configuration.label.opacity(configuration.isPressed ? 0.75 : 1)
    }
}
