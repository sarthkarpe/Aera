<div align="center">

<img src="assets/logo.png" width="110" alt="Aera logo"/>

# Aera

**Your face is the password.**<br>
Unlock your Mac's lock screen and secure individual apps with a single look.

![macOS](https://img.shields.io/badge/macOS-14.0%2B-black?style=for-the-badge&logo=apple&logoColor=white)
![Apple Silicon](https://img.shields.io/badge/Apple%20Silicon-Native-0071E3?style=for-the-badge&logo=apple&logoColor=white)
![Privacy](https://img.shields.io/badge/100%25-On--Device-34C759?style=for-the-badge&logo=shield&logoColor=white)

</div>

---

## Features

- **Lock Screen unlock:** wake your Mac, look at the screen, and you're logged in.
- **App Lock:** blur selected apps (Messages, Notes, Mail) until you verify with Face, Touch ID, or password.
- **Adaptive privacy blurs:** blur the whole display or only the locked app's window.
- **Relock policies:** per app, on launch, after 5–15 minutes, or when you switch away.
- **Notch island:** a native-feeling overlay that gives feedback during scans.
- **Guided setup:** choose Lock Screen, App Lock, or both.

## Privacy and security

- All recognition runs on-device with Core ML. No data leaves the Mac.
- No photos are stored: only a numeric face embedding, encrypted (AES-GCM) with a key held in the macOS Keychain.
- A liveness check rejects photos and screens, but a webcam is not a depth sensor like Face ID. Keep a strong password.
- Lock Screen unlock stores your login password (encrypted) and types it for you, which needs Accessibility permission.

## Build

Requires an Apple Silicon Mac, macOS 14+, and Xcode 16+.

```bash
scripts/rebuild-clean.sh 1.0.1  # clean dependency resolution, tests, fresh .app and DMG
open dist/Aera.app
```

To open the project in Xcode, run `xed .` from this folder (opens `Package.swift`). The clean rebuild script removes old build artifacts and stops a running Aera process before building. This matters when updating from an earlier build: an already-installed or still-running app can continue showing the old sidebar, folder icon, or shield menu-bar symbol even after the source has changed. Launch the freshly built `dist/Aera.app` from this project to verify the new horizontal navigation and Aera logo. The script requires macOS, Xcode command-line tools, and network access for Swift Package Manager dependencies. Use `scripts/build-app.sh` directly only when you intentionally want an incremental build.

Automatic updates are disabled in this fork (no update feed is configured).

## Credits and license

Aera is a modified fork of **[Hey Mac](https://github.com/iharshitmaurya/HeyMac)** by Harshit Maurya, released under the MIT License (see `LICENSE`). Model and animation credits are in `THIRD_PARTY_NOTICES.md`.

## Camera permission troubleshooting

Build and launch the packaged `dist/Aera.app` on macOS for camera testing. The packaged app includes `NSCameraUsageDescription`; launching the SwiftPM executable directly is not a reliable way to test macOS camera authorization. In Lock Screen or Face settings, use **Allow Camera Access…**. If permission has not been requested, Aera asks macOS for access. If access was previously denied, Aera opens System Settings → Privacy & Security → Camera; enable Aera there, then return to Aera. The app refreshes the permission status periodically.

The menu-bar icon is a transparent, high-resolution white face-scanning glyph (`Sources/AeraApp/Brand/aera-menu.png`), rendered as a macOS template image so it adapts to the menu-bar appearance.


## Accessibility permission still says it is missing

macOS ties Accessibility permissions to the running app's code-signing identity, not only its display name. If an earlier build was ad-hoc signed, renamed, or launched from a different path, System Settings can show duplicate entries while the running process still reports that it is not trusted. Aera uses `AXIsProcessTrusted()` for the actual current-process check, so it intentionally continues to show the warning until macOS grants trust to that process.

1. Run `scripts/rebuild-clean.sh` on your Mac. If needed, it creates a stable local signing identity named **FaceUnlock Local Signing** and uses it for the packaged app. macOS may ask you to approve trusting the certificate for code signing.
2. If the warning persists, run `scripts/reset-accessibility-permission.sh` once. This resets Aera's Accessibility grant for its bundle identifier; it does not grant access automatically.
3. Launch only the packaged app at `dist/Aera.app` (do not launch the `.build` executable or an older copy in Applications).
4. In System Settings → Privacy & Security → Accessibility, enable the entry for that exact `dist/Aera.app` build. Reopen Aera and verify the warning clears.

Camera access and Accessibility access are separate permissions. A green Camera status does not mean Accessibility is trusted, and Accessibility being enabled does not prove that lock-screen password entry itself will succeed. Keep your normal Mac password and Touch ID available.
