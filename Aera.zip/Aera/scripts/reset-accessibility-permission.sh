#!/bin/bash
# One-time repair for stale/duplicate Accessibility permission entries after app identity changes.
set -euo pipefail
if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This script must run on macOS." >&2
  exit 2
fi
BUNDLE_ID="com.sarthkarpe.aera"
echo "This resets Aera's Accessibility grant for bundle ID $BUNDLE_ID."
echo "You will need to enable Accessibility for the newly built Aera.app again."
read -r -p "Continue? [y/N] " answer
case "$answer" in
  y|Y|yes|YES) ;;
  *) echo "Cancelled."; exit 0 ;;
esac
tccutil reset Accessibility "$BUNDLE_ID"
echo
echo "Now launch the packaged app, not the SwiftPM executable:"
echo "  open \"$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)/dist/Aera.app\""
echo "Then go to System Settings > Privacy & Security > Accessibility and enable that Aera entry."
