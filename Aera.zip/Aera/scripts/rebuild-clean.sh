#!/bin/bash
# Clean rebuild the current Aera source, then package a fresh Aera.app.
# Run this from the extracted Aera project folder on macOS with Xcode installed.
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"

if [[ "$(uname -s)" != "Darwin" ]]; then
  echo "This script must run on macOS; Aera uses SwiftUI, AppKit, Core ML, and macOS security APIs." >&2
  exit 2
fi

# Stop a previously installed/running build so the user does not keep looking at a stale UI.
if pgrep -x Aera >/dev/null 2>&1; then
  echo "Stopping the currently running Aera process..."
  pkill -x Aera || true
  sleep 1
fi

# Accessibility/Camera TCC grants are tied to the app's signing identity. Ad-hoc
# signing can cause duplicate Aera entries or grants that don't apply to a rebuilt app.
# Create one stable local signing identity once, then reuse it for future builds.
if ! source "$ROOT/scripts/lib-signing.sh"; then
  echo "Could not load signing helpers." >&2
  exit 1
fi
if ! signing_identity_available; then
  echo "A stable local signing identity is needed so macOS permissions remain attached to Aera."
  "$ROOT/scripts/create-signing-identity.sh"
fi

rm -rf .build dist
swift package resolve
swift test
scripts/build-app.sh "${1:-1.0.1}"
echo
echo "Fresh build complete: $ROOT/dist/Aera.app"
echo "Launch this exact app with: open \"$ROOT/dist/Aera.app\""
echo "If Accessibility still shows stale duplicate entries, run scripts/reset-accessibility-permission.sh once,"
echo "then reopen dist/Aera.app and enable its Accessibility permission."
